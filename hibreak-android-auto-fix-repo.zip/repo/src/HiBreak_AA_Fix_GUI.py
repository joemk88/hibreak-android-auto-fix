#!/usr/bin/env python3
"""
HiBreak / HiBreak Pro - Android Auto display fix (GUI)
=====================================================

Bigme's e-ink text-enhancement pass leaks into the Android Auto video stream
sent to the car, causing dark halos on the head-unit display. This tool sets an
app's text-enhance value to 0 via Bigme's own system service
(xrz_display_policy_service, transaction 34 = setTextEnhanceForPackage).

It is per-app and permanent (survives reboots). Because the value applies to the
app on the phone too, only patch apps you don't mind looking slightly lighter on
the e-ink panel (Android Auto, dialer, maps, etc).

Requires: Python 3 (with tkinter) and adb on PATH, or adb.exe next to this file.
"""

import os
import re
import sys
import subprocess
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

SERVICE = "xrz_display_policy_service"
TXN_SET_TEXT_ENHANCE = 34
DEFAULT_TEXT_ENHANCE = 70
FLOAT_ANCHOR = 0x3f800000
RM_OFFSET = 3

PRESET_APPS = [
    ("com.google.android.projection.gearhead", True),
    ("com.google.android.dialer", False),
    ("com.google.android.apps.maps", False),
]

# Known original (pre-patch) text-enhance values, from decompiled defaults / logs.
# Used to label the per-row Reset button correctly when the live baseline is
# unavailable (e.g. app already patched to 0 before this session).
KNOWN_DEFAULTS = {
    "com.google.android.projection.gearhead": 80,
    "com.android.settings": 50,
}

# ---- theme ----
BG        = "#2b2d31"   # charcoal grey
BG_PANEL  = "#33363b"
BG_ROW    = "#3a3d42"
FG        = "#e8e8e8"
FG_DIM    = "#a8adb4"
ACCENT    = "#2ea043"   # green
ACCENT_HI = "#3fb950"
WARN      = "#d29922"
RED       = "#f85149"


# ----------------------------- adb helpers -----------------------------------

def find_adb():
    """Locate adb: bundled (PyInstaller), then next to this file, then PATH."""
    candidates = []
    exe_name = "adb.exe" if os.name == "nt" else "adb"
    # 1. PyInstaller one-file bundle extracts data to sys._MEIPASS
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(os.path.join(meipass, exe_name))
    # 2. Next to the script / exe
    here = os.path.dirname(os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False)
                                           else __file__))
    candidates.append(os.path.join(here, exe_name))
    for c in candidates:
        if os.path.exists(c):
            return c
    return "adb"  # fall back to PATH


ADB = find_adb()


def adb(args, timeout=15):
    try:
        p = subprocess.run(
            [ADB] + args, capture_output=True, text=True, timeout=timeout,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        return p.returncode, p.stdout.strip(), p.stderr.strip()
    except FileNotFoundError:
        return 127, "", "adb not found"
    except subprocess.TimeoutExpired:
        return 124, "", "adb timed out"


def check_device():
    rc, out, err = adb(["devices"])
    if rc != 0:
        return False, err or "adb error"
    lines = [l for l in out.splitlines()[1:] if l.strip()]
    devices = [l for l in lines if l.split("\t")[-1] == "device"]
    unauth = [l for l in lines if l.split("\t")[-1] == "unauthorized"]
    if unauth:
        return False, "Device unauthorised - unlock phone and tap 'Allow USB debugging'."
    if not devices:
        return False, "No device detected. Check cable and USB debugging."
    if len(devices) > 1:
        return False, "More than one device connected. Unplug the others."
    return True, "Device connected."


def is_bigme():
    _, out, _ = adb(["shell", "service", "list"])
    return SERVICE in out


def list_packages():
    rc, out, _ = adb(["shell", "pm", "list", "packages"])
    if rc != 0:
        return []
    return sorted(l.replace("package:", "").strip()
                  for l in out.splitlines() if l.startswith("package:"))


def _parcel_ints(dump):
    flat = []
    for grp in re.findall(r"0x[0-9a-fA-F]+:\s+((?:[0-9a-fA-F]{8}\s*){1,4})", dump):
        flat.extend(re.findall(r"[0-9a-fA-F]{8}", grp))
    return [int(w, 16) for w in flat]


def get_policy_fields(pkg):
    """Effective text-enhance is the 2nd-to-last int in the parcel.
    Verified: Settings=50, Chrome=70, AA=0, Maps=0."""
    rc, out, _ = adb(["shell", "service", "call", SERVICE, "1", "s16", pkg])
    if rc != 0 or "Parcel" not in out:
        return None
    ints = _parcel_ints(out)
    if len(ints) < 2:
        return {"text_enhance": None, "refresh_mode": None, "raw": out}
    te = ints[-2]
    if not (0 <= te <= 100):
        te = None
    rm = None
    try:
        a = ints.index(FLOAT_ANCHOR)
        if a + RM_OFFSET < len(ints):
            rm = ints[a + RM_OFFSET]
    except ValueError:
        pass
    return {"text_enhance": te, "refresh_mode": rm, "raw": out}


def get_text_enhance(pkg):
    f = get_policy_fields(pkg)
    return f["text_enhance"] if f else None


def get_raw_policy(pkg):
    _, out, _ = adb(["shell", "service", "call", SERVICE, "1", "s16", pkg])
    return out


def set_text_enhance(pkg, value):
    _, out, err = adb(["shell", "service", "call", SERVICE, str(TXN_SET_TEXT_ENHANCE),
                       "s16", pkg, "i32", str(value)])
    return ("00000001" in out), (out or err)


# ------------------------------- GUI -----------------------------------------

class AppRow:
    def __init__(self, app, pkg, ticked, editable):
        self.app = app
        self.editable = editable
        self.var_check = tk.BooleanVar(value=ticked)
        self.baseline = None   # value at first read (before any patch this session)

        self.frame = tk.Frame(app.table, bg=BG_ROW, padx=6, pady=4)

        self.chk = tk.Label(
            self.frame, textvariable=None, width=2, height=1,
            bg=BG_PANEL, fg=ACCENT_HI, bd=1, relief="solid",
            font=("TkDefaultFont", 11, "bold"), cursor="hand2",
        )
        self.chk.grid(row=0, column=0, padx=(2, 8))
        self.chk.bind("<Button-1>", lambda e: self._toggle())
        self._sync_toggle()

        if editable:
            self.pkg_var = tk.StringVar(value="")
            self.combo = ttk.Combobox(self.frame, values=app.all_pkgs,
                                      textvariable=self.pkg_var, width=44,
                                      style="Dark.TCombobox")
            self.combo.grid(row=0, column=1, sticky="w", padx=(0, 8))
            self.combo.bind("<<ComboboxSelected>>", lambda e: self.refresh_value())
        else:
            self.pkg_var = tk.StringVar(value=pkg)
            tk.Label(self.frame, text=pkg, width=46, anchor="w",
                     bg=BG_ROW, fg=FG).grid(row=0, column=1, sticky="w", padx=(0, 8))

        self.val_lbl = tk.Label(self.frame, text="current: -", width=18, anchor="w",
                                bg=BG_ROW, fg=FG_DIM)
        self.val_lbl.grid(row=0, column=2, sticky="w")

        self.reset_btn = tk.Button(self.frame, text="Reset", command=self.reset,
                                   bg=BG_PANEL, fg=FG, activebackground="#4a4d52",
                                   activeforeground=FG, bd=0, padx=8, pady=1,
                                   highlightthickness=0)
        self.reset_btn.grid(row=0, column=3, padx=(8, 2))

        self.frame.columnconfigure(1, weight=1)

    def _toggle(self):
        self.var_check.set(not self.var_check.get())
        self._sync_toggle()

    def _sync_toggle(self):
        if self.var_check.get():
            self.chk.config(text="\u2713", fg=ACCENT_HI, bg=BG_PANEL)  # green check
        else:
            self.chk.config(text=" ", fg=BG_PANEL, bg=BG_PANEL)       # empty box

    def package(self):
        return self.pkg_var.get().strip()

    def is_checked(self):
        return self.var_check.get()

    def _render_label(self, te):
        if te is None:
            self.val_lbl.config(text="current: unknown", fg=WARN)
        elif te == 0:
            self.val_lbl.config(text="current: 0 (patched)", fg=ACCENT_HI)
        else:
            self.val_lbl.config(text=f"current: {te}", fg=FG)
        # keep the reset button labelled with the value it will restore
        self.reset_btn.config(text=f"Reset to {self._original_value()}")

    def refresh_value(self):
        pkg = self.package()
        if not pkg:
            return
        te = get_text_enhance(pkg)
        if self.baseline is None and te not in (0, None):
            # first non-zero reading is the app's true original (pre-patch) value
            self.baseline = te
        self._render_label(te)

    def set_after_write(self, te):
        # update label after a patch/reset without overwriting baseline
        self._render_label(te)

    def _original_value(self):
        """Best guess at this app's pre-patch text-enhance."""
        if self.baseline not in (0, None):
            return self.baseline
        return KNOWN_DEFAULTS.get(self.package(), DEFAULT_TEXT_ENHANCE)

    def reset(self):
        pkg = self.package()
        if not pkg:
            return
        target = self._original_value()
        if not messagebox.askyesno("Reset to default",
                                   f"Set {pkg} back to text-enhance {target}?\n\n"
                                   "This is the app's original value where known, otherwise the "
                                   "system default (70). For the exact original, use "
                                   "'Restore from backup'."):
            return
        ok, _ = set_text_enhance(pkg, target)
        if ok:
            self.set_after_write(target)
            self.app.set_status(f"{pkg} reset to {target}.")
        else:
            self.app.set_status(f"Reset failed for {pkg}.")

    def grid(self, **kw):
        self.frame.grid(**kw)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("HiBreak - Android Auto Display Fix")
        self.geometry("760x600")
        self.configure(bg=BG)
        self.rows = []
        self.all_pkgs = []
        self.backup_saved = False

        self._style()
        self._build_header()
        self._build_table()
        self._build_buttons()
        self._build_status()
        self.after(200, self.startup_checks)

    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("Dark.TCombobox", fieldbackground=BG_PANEL, background=BG_PANEL,
                    foreground=FG, arrowcolor=FG)
        s.map("Dark.TCombobox", fieldbackground=[("readonly", BG_PANEL)])

    def _build_header(self):
        head = tk.Frame(self, bg=BG, padx=14, pady=12)
        head.pack(fill="x")
        tk.Label(head, text="Android Auto Display Fix  -  HiBreak / HiBreak Pro",
                 bg=BG, fg=FG, font=("TkDefaultFont", 13, "bold")).pack(anchor="w")
        msg = (
            "Tick the apps you use while driving and press Apply. This sets their e-ink "
            "text-enhance to 0 so they stop corrupting the Android Auto display in the car. "
            "The change is permanent and survives reboots.\n\n"
            "IMPORTANT - this is NOT the same as the 'Text Enhancement' toggle inside E-Ink "
            "Centre. That toggle does not affect this value. This tool writes the underlying "
            "per-app display policy directly, via Bigme's own system service.\n\n"
            "The value also applies on the phone itself, so a patched app will look slightly "
            "lighter (less bold) on the e-ink screen. Save a backup first so you can restore "
            "originals later."
        )
        tk.Label(head, text=msg, bg=BG, fg=FG_DIM, wraplength=720, justify="left",
                 font=("TkDefaultFont", 9)).pack(anchor="w", pady=(6, 0))

    def _build_table(self):
        wrap = tk.LabelFrame(self, text=" Apps ", bg=BG_PANEL, fg=FG, padx=8, pady=6,
                             bd=0, highlightthickness=0)
        wrap.pack(fill="both", expand=True, padx=14, pady=(4, 4))

        hdr = tk.Frame(wrap, bg=BG_PANEL)
        hdr.pack(fill="x", pady=(0, 4))
        tk.Label(hdr, text="Patch", width=6, bg=BG_PANEL, fg=FG_DIM).grid(row=0, column=0)
        tk.Label(hdr, text="Package", width=46, anchor="w", bg=BG_PANEL,
                 fg=FG_DIM).grid(row=0, column=1, sticky="w")
        tk.Label(hdr, text="Value", width=18, anchor="w", bg=BG_PANEL,
                 fg=FG_DIM).grid(row=0, column=2, sticky="w")

        canvas = tk.Canvas(wrap, bg=BG_PANEL, borderwidth=0, highlightthickness=0)
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=canvas.yview)
        self.table = tk.Frame(canvas, bg=BG_PANEL)
        self.table.bind("<Configure>",
                        lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.table, anchor="nw")
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self._canvas = canvas

    def _add_button_row(self):
        # the "+ Add app" control lives as the last item under the rows
        if getattr(self, "_addrow_frame", None):
            self._addrow_frame.destroy()
        self._addrow_frame = tk.Frame(self.table, bg=BG_PANEL, pady=6)
        btn = tk.Button(self._addrow_frame, text="  +  Add app", command=self.add_row,
                        bg=BG_ROW, fg=FG, activebackground="#4a4d52",
                        activeforeground=FG, bd=0, padx=12, pady=4, highlightthickness=0)
        btn.pack(anchor="w", padx=2)
        self._addrow_frame.grid(row=len(self.rows), column=0, sticky="w")

    def _build_buttons(self):
        bar = tk.Frame(self, bg=BG, padx=14, pady=8)
        bar.pack(fill="x")
        tk.Button(bar, text="Save backup", command=self.save_backup,
                  bg=BG_ROW, fg=FG, activebackground="#4a4d52", activeforeground=FG,
                  bd=0, padx=12, pady=6, highlightthickness=0).pack(side="left")
        tk.Button(bar, text="Restore from backup...", command=self.restore,
                  bg=BG_ROW, fg=FG, activebackground="#4a4d52", activeforeground=FG,
                  bd=0, padx=12, pady=6, highlightthickness=0).pack(side="left", padx=(8, 0))
        tk.Button(bar, text="Refresh values", command=self.refresh_all_values,
                  bg=BG_ROW, fg=FG, activebackground="#4a4d52", activeforeground=FG,
                  bd=0, padx=12, pady=6, highlightthickness=0).pack(side="left", padx=(8, 0))
        # Apply - green, bottom right
        tk.Button(bar, text="Apply", command=self.apply,
                  bg=ACCENT, fg="white", activebackground=ACCENT_HI,
                  activeforeground="white", bd=0, padx=22, pady=6,
                  font=("TkDefaultFont", 10, "bold"),
                  highlightthickness=0).pack(side="right")

    def _build_status(self):
        self.status = tk.StringVar(value="Starting...")
        bar = tk.Frame(self, bg=BG, padx=14, pady=4)
        bar.pack(fill="x")
        tk.Label(bar, textvariable=self.status, bg=BG, fg=FG_DIM,
                 anchor="w").pack(fill="x")

    # ---- logic ----

    def set_status(self, text):
        self.status.set(text)
        self.update_idletasks()

    def startup_checks(self):
        self.set_status("Checking device...")
        ok, msg = check_device()
        if not ok:
            self.set_status(msg)
            messagebox.showerror("Device", msg)
            return
        if not is_bigme():
            self.set_status("Not a Bigme device - service missing.")
            messagebox.showerror("Wrong device",
                                 "This phone doesn't expose Bigme's display-policy service.")
            return
        self.set_status("Scanning installed apps...")
        self.all_pkgs = list_packages()
        for pkg, ticked in PRESET_APPS:
            self.add_row(pkg=pkg, ticked=ticked, editable=False)
        self.set_status(f"Ready. {len(self.all_pkgs)} apps found. Save a backup before applying.")

    def add_row(self, pkg="", ticked=False, editable=None):
        if editable is None:
            editable = True
        row = AppRow(self, pkg, ticked, editable)
        row.grid(row=len(self.rows), column=0, sticky="ew", pady=2)
        self.table.columnconfigure(0, weight=1)
        self.rows.append(row)
        self._add_button_row()
        if pkg:
            row.refresh_value()

    def refresh_all_values(self):
        self.set_status("Reading current values...")
        for r in self.rows:
            if r.package():
                r.refresh_value()
        self.set_status("Values refreshed.")

    def collect_rows(self):
        seen, out = set(), []
        for r in self.rows:
            pkg = r.package()
            if pkg and pkg not in seen:
                seen.add(pkg)
                out.append(r)
        return out

    def save_backup(self):
        rows = self.collect_rows()
        if not rows:
            messagebox.showwarning("Nothing to back up", "Add at least one app first.")
            return
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", initialfile=f"hibreak_aa_backup_{ts}.txt",
            filetypes=[("Text", "*.txt")])
        if not path:
            return
        self.set_status("Reading current values for backup...")
        lines = [
            "HiBreak Android Auto fix - backup of current display policies",
            f"Saved: {datetime.datetime.now().isoformat()}",
            "",
            "Each app's original text-enhance was read live and encoded in the restore",
            "command below. Run a line with adb, or use this tool's 'Restore from backup'.",
            "",
        ]
        for r in rows:
            pkg = r.package()
            f = get_policy_fields(pkg)
            te = f["text_enhance"] if f else None
            raw = f["raw"] if f else get_raw_policy(pkg)
            orig = te if te is not None else DEFAULT_TEXT_ENHANCE
            note = "" if te is not None else "  (unreadable; using default 70)"
            lines.append(f"# {pkg}  original text-enhance = {te}{note}")
            lines.append(f"#   raw: {raw}")
            lines.append(f"adb shell service call {SERVICE} {TXN_SET_TEXT_ENHANCE} s16 {pkg} i32 {orig}")
            lines.append("")
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("\n".join(lines))
        except OSError as e:
            messagebox.showerror("Save failed", str(e))
            return
        self.backup_saved = True
        self.set_status(f"Backup saved to {path}")
        messagebox.showinfo("Backup saved",
                            "Backup written. Keep this file - it restores the originals.")

    def apply(self):
        if not self.backup_saved:
            if not messagebox.askyesno("No backup",
                                       "You haven't saved a backup yet. Apply anyway?"):
                return
        rows = [r for r in self.collect_rows() if r.is_checked()]
        if not rows:
            messagebox.showinfo("Nothing ticked", "Tick at least one app to patch.")
            return
        good, bad = [], []
        for r in rows:
            pkg = r.package()
            self.set_status(f"Patching {pkg} ...")
            ok, _ = set_text_enhance(pkg, 0)
            if ok:
                r.set_after_write(0)
                good.append(pkg)
            else:
                bad.append(pkg)
        msg = f"Patched {len(good)} app(s) to 0."
        if bad:
            msg += "\n\nFailed:\n" + "\n".join(bad)
        self.set_status(msg.replace("\n", " "))
        messagebox.showinfo("Done", msg)

    def restore(self):
        path = filedialog.askopenfilename(filetypes=[("Text", "*.txt")])
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as fh:
                text = fh.read()
        except OSError as e:
            messagebox.showerror("Open failed", str(e))
            return
        cmds = re.findall(r"service call \S+ \d+ s16 (\S+) i32 (\d+)", text)
        if not cmds:
            messagebox.showwarning("Nothing to restore", "No restore commands in that file.")
            return
        if not messagebox.askyesno("Restore",
                                   f"Restore {len(cmds)} app(s) to backup values?"):
            return
        n = 0
        for pkg, val in cmds:
            self.set_status(f"Restoring {pkg} -> {val} ...")
            ok, _ = set_text_enhance(pkg, int(val))
            n += 1 if ok else 0
        self.set_status(f"Restored {n}/{len(cmds)} app(s).")
        messagebox.showinfo("Restore complete", f"Restored {n} of {len(cmds)} app(s).")


if __name__ == "__main__":
    App().mainloop()
