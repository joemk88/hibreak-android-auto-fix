# How to publish this to GitHub

Everything for the repo is in this folder. Two ways to get it online.

## Option A - web upload (no git, easiest)

1. Go to https://github.com/new
2. Name it e.g. `hibreak-android-auto-fix`, add a short description, make it **Public**,
   and click **Create repository**.
3. On the new repo page, click **"uploading an existing file"**.
4. Drag in: `README.md`, `TECHNICAL.md`, `LICENSE`, `.gitignore`, `build_windows.bat`,
   and the `src` folder (with `HiBreak_AA_Fix_GUI.py` inside). Commit.
5. Open `LICENSE` and replace `[YOUR NAME]` with your name/handle (Edit → commit).

### Attach the .exe as a Release (don't commit the exe to the repo)

1. On the repo page: **Releases** (right sidebar) → **Create a new release**.
2. Tag: `v1.0`.  Title: `v1.0`.
3. Drag `HiBreak_AA_Fix.exe` into the "Attach binaries" box.
4. Publish. The README's Releases link will now point people to the download.

## Option B - git command line

```
cd path\to\this\folder
git init
git add .
git commit -m "Initial release: HiBreak Android Auto display fix"
git branch -M main
git remote add origin https://github.com/<you>/hibreak-android-auto-fix.git
git push -u origin main
```

Then create the Release and attach the exe as in Option A (step "Attach the .exe").

## Before you publish - checklist

- [ ] Put your name in `LICENSE` (replaces `[YOUR NAME]`).
- [ ] Do **not** commit `adb.exe` / the DLLs (already in `.gitignore`) - they're Google's.
- [ ] Do **not** commit `build/`, `dist/`, `*.spec` (already ignored).
- [ ] Attach `HiBreak_AA_Fix.exe` as a **Release asset**, not a committed file
      (keeps the repo small; exes don't belong in git).
- [ ] Optional: add a screenshot of the GUI to the README (drag an image into an
      Issues comment to get a URL, or commit it and reference it).

## Note on the exe and antivirus

Unsigned PyInstaller exes sometimes trip SmartScreen / AV false-positives. Mention in your
Reddit post that this is expected, that the source is right there in the repo to inspect or
run instead, and that people can build the exe themselves with `build_windows.bat`.
