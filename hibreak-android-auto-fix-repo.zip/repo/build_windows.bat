@echo off
REM ============================================================
REM  Build HiBreak_AA_Fix.exe  (run on Windows)
REM ============================================================
REM
REM  Before running:
REM   1. Install Python 3 from python.org (tick "Add to PATH").
REM   2. pip install pyinstaller
REM   3. Download "SDK Platform Tools" from Google, unzip, and copy
REM      adb.exe, AdbWinApi.dll, AdbWinUsbApi.dll into this folder
REM      (the repo root), next to this script.
REM
REM  Result: dist\HiBreak_AA_Fix.exe  (single file, adb bundled inside)
REM ============================================================

setlocal
cd /d "%~dp0"

if not exist adb.exe (
    echo [ERROR] adb.exe not found in this folder.
    echo Download SDK Platform Tools from Google and copy adb.exe,
    echo AdbWinApi.dll and AdbWinUsbApi.dll here, then re-run.
    pause
    exit /b 1
)

echo Checking PyInstaller...
python -m PyInstaller --version >nul 2>&1
if errorlevel 1 (
    echo Installing PyInstaller...
    python -m pip install pyinstaller
)

echo Building...
python -m PyInstaller --onefile --windowed ^
  --name "HiBreak_AA_Fix" ^
  --add-binary "adb.exe;." ^
  --add-binary "AdbWinApi.dll;." ^
  --add-binary "AdbWinUsbApi.dll;." ^
  src\HiBreak_AA_Fix_GUI.py

echo.
if exist "dist\HiBreak_AA_Fix.exe" (
    echo Done.  Your file is:  dist\HiBreak_AA_Fix.exe
) else (
    echo Build did not produce an exe - check the messages above.
)
pause
endlocal
